package packageModel;

public enum Sex
{
    MASCULIN,
    FEMININ,
    NEDEFINIT
}
