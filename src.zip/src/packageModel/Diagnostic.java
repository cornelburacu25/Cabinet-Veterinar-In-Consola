package packageModel;

public enum Diagnostic
{
    Nedeterminat,
    RABIE,
    PARVOVIROZA,
    CORONAVIROZA,
    HEPATITA_INFECTIOASA,
    LEPTOSPIROZA,
    TUSE_CANISA,
    PARAINFLUENZA,
    BOLI_PARAZITARE,
    ALTE_BOLI
}