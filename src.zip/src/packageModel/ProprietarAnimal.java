package packageModel;

public class ProprietarAnimal extends Persoana
{
    private Animal animal;
    public ProprietarAnimal()
    {
        super();
        this.animal = null;
    }
    public ProprietarAnimal(String nume, String adresa, String telefon, String email, Sex sex, Animal animal)
    {
        super(nume, adresa, telefon, email, sex);
        this.animal = animal;
    }
    public void afisareProprietarAnimal()
    {
        super.afisarePersoana();

        System.out.println("===========================================================");
        System.out.println("Animalul proprietarului este afisat mai jos: ");

        animal.afisareAnimal();
    }
    public void programareConsultatie(Consultatie c)
    {
        c.setAnimal(this.animal);
        c.citesteDetaliiConsultatie();
    }
    public void verificareStatusConsultatie(Consultatie c)
    {
        if(c.getEsteFinalizata())
        {
            System.out.println("Consultatia a fost finalizata!");
            return;
        }

        System.out.println("Consultatia nu este finalizata!");
    }
}