package packageModel;

public class MedicVeterinar extends AsistentMedical
{
    public MedicVeterinar()
    {
        super();
    }
    public MedicVeterinar(String nume, String adresa, String telefon, String email, Sex sex, Consultatie[] listaConsultatii)
    {
        super(nume, adresa, telefon, email, sex, listaConsultatii);
    }
    public void afisareMedicVeterinar()
    {
        super.afisareAsistentMedical();
    }
}