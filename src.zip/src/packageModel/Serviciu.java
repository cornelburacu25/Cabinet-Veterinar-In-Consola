package packageModel;

public enum Serviciu
{
    Nedeterminat,
    VACCINARE,
    DEPARAZITARE,
    MICROCHIPARE,
    ANALIZE,
    OPERATIE,
    ALTE_SERVICII
}